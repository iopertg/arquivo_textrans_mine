Hello, sorry for making you download both the 1.19 and 1.20 versions of this resource pack, im still figuring out how to set up the downloads properly

To install Up to Snuff, please extract this .zip archive into your resourcepacks folder and then depending on your version of minecraft, either use "Up-to-Snuff_1.2.4_MC1.19.zip" or "Up-to-Snuff_1.2.4_MC1.20.zip", don't forget to check out the readmes inside!

I recommend extracting these two .zips too, if you wish to customise.
